package br.com.senac.leitor;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

import br.com.senac.modelo.Evento;
import br.com.senac.modelo.Organizador;

public class OrganizadorCSV {

	public ArrayList<Organizador> lerArquivo(ArrayList<Evento> eventos) {
		ArrayList<Organizador> organizadores = new ArrayList<>();

		Scanner sc;
		try {
			sc = new Scanner(new File("organizadores.csv"));
			sc.useDelimiter("[,\n]");

		} catch (FileNotFoundException e) {
			System.out.println("Arquivo não encontrado.");
			return organizadores;
		}

		boolean ehPrimeiraLinha = true;

		while (sc.hasNext()) {
			if (ehPrimeiraLinha) {
				
				criaOrganizador(sc, eventos);
				
				ehPrimeiraLinha = false;
				
			} else {
				Organizador o = criaOrganizador(sc, eventos);

				organizadores.add(o);
			}
		}
		sc.close();
		
		return organizadores;
	}

	private static Organizador criaOrganizador(Scanner sc, ArrayList<Evento> eventos) {
		Organizador organizador = new Organizador();
		organizador.setCpf(sc.next());
		organizador.setNome(sc.next());
		organizador.setEmail(sc.next());
		organizador.setTelefone(sc.next());
		
		String nomeEvento = sc.next();
		
		for (Evento evento : eventos) {
			if(nomeEvento.equals(evento.getNome())) {
				evento.getOrganizadores().add(organizador);
				organizador.setEvento(evento);
			}
		}
		return organizador;
	}
}
