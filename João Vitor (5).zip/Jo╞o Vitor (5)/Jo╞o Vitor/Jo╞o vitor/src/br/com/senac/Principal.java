package br.com.senac;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import br.com.senac.leitor.EventoCSV;
import br.com.senac.leitor.OrganizadorCSV;
import br.com.senac.leitor.PalestraCSV;
import br.com.senac.leitor.PalestranteCSV;
import br.com.senac.leitor.ParticipanteCSV;
import br.com.senac.modelo.Certificado;
import br.com.senac.modelo.Evento;
import br.com.senac.modelo.Organizador;
import br.com.senac.modelo.Palestra;
import br.com.senac.modelo.Palestrante;
import br.com.senac.modelo.Participante;
import br.com.senac.modelo.Pessoa;

public class Principal {

	public static void main(String[] args) throws IOException {
		ArrayList<Pessoa> pessoas = new ArrayList<>();
		
		EventoCSV eventoCSV = new EventoCSV();
		ArrayList<Evento> eventos = eventoCSV.lerArquivo();
		
		ParticipanteCSV participanteCSV = new ParticipanteCSV();
		ArrayList<Participante> participantes = participanteCSV.lerArquivo(eventos);
		
		PalestranteCSV palestranteCSV = new PalestranteCSV();
		ArrayList<Palestrante> palestrantes = palestranteCSV.lerArquivo(eventos);
		
		PalestraCSV palestraCSV = new PalestraCSV();
		ArrayList<Palestra> palestras = palestraCSV.lerArquivo(palestrantes, eventos);
		
		OrganizadorCSV organizadorCSV = new OrganizadorCSV();
		ArrayList<Organizador> organizadores = organizadorCSV.lerArquivo(eventos);
		
		pessoas.addAll(participantes);
		pessoas.addAll(organizadores);
		pessoas.addAll(palestrantes);
		
		String certificadoCSV = "";
		for (Pessoa pessoa : pessoas) {
			Certificado certificado = new Certificado(pessoa);
			certificadoCSV = certificadoCSV + certificado.getEvento().getNome() + "," + certificado.getPessoa().getCpf() + "\n";
		}
		
		FileWriter writer = new FileWriter("certificados.csv");
		writer.append(certificadoCSV);
		writer.flush();
        writer.close();
	}

}
