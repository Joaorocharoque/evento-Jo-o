package br.com.senac.modelo;

public class Palestrante extends Pessoa{

	private String curriculo;

	public String getCurriculo() {
		return curriculo;
	}

	public void setCurriculo(String curriculo) {
		this.curriculo = curriculo;
	}

	@Override
	public String toString() {
		return "Palestrante [nome=" + nome + ", email=" + email + ", curriculo=" + curriculo + ", telefone=" + telefone + "]";
	}
}
