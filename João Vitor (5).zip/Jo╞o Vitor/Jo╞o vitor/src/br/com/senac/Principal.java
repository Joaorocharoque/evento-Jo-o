package br.com.senac;

import java.util.ArrayList;

import br.com.senac.leitor.EventoCSV;
import br.com.senac.leitor.OrganizadorCSV;
import br.com.senac.leitor.PalestraCSV;
import br.com.senac.leitor.PalestranteCSV;
import br.com.senac.leitor.ParticipanteCSV;
import br.com.senac.modelo.Evento;
import br.com.senac.modelo.Organizador;
import br.com.senac.modelo.Palestra;
import br.com.senac.modelo.Palestrante;
import br.com.senac.modelo.Participante;

public class Principal {

	public static void main(String[] args) {
		EventoCSV eventoCSV = new EventoCSV();
		ArrayList<Evento> eventos = eventoCSV.lerArquivo();
		
		ParticipanteCSV participanteCSV = new ParticipanteCSV();
		ArrayList<Participante> participantes = participanteCSV.lerArquivo(eventos);
		
		PalestranteCSV palestranteCSV = new PalestranteCSV();
		ArrayList<Palestrante> palestrantes = palestranteCSV.lerArquivo();
		
		PalestraCSV palestraCSV = new PalestraCSV();
		ArrayList<Palestra> palestras = palestraCSV.lerArquivo(palestrantes, eventos);
		
		OrganizadorCSV organizadorCSV = new OrganizadorCSV();
		ArrayList<Organizador> organizadores = organizadorCSV.lerArquivo(eventos);
		
	}

}
