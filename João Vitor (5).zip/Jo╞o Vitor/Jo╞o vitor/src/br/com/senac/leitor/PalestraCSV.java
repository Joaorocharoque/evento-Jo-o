package br.com.senac.leitor;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

import br.com.senac.modelo.Evento;
import br.com.senac.modelo.Palestra;
import br.com.senac.modelo.Palestrante;

public class PalestraCSV {
	
	public PalestraCSV() {
	}

	public ArrayList<Palestra> lerArquivo(ArrayList<Palestrante> palestrantes, ArrayList<Evento> eventos) {
		ArrayList<Palestra> palestras = new ArrayList<>();
		Scanner sc;
		
		try {
			sc = new Scanner(new File("palestras.csv"));
			sc.useDelimiter("[,\n]");

		} catch (FileNotFoundException e) {
			System.out.println("Arquivo não encontrado.");
			return palestras;
		}

		boolean ehPrimeiraLinha = true;

		while (sc.hasNext()) {
			if (ehPrimeiraLinha) {
				
				criaPalestra(sc, palestrantes, eventos);
				
				ehPrimeiraLinha = false;
				
			} else {
				Palestra p = criaPalestra(sc, palestrantes, eventos);
				
				palestras.add(p);
			}
		}
		
		sc.close();
		
		return palestras;
	}

	private Palestra criaPalestra(Scanner sc, ArrayList<Palestrante> palestrantes, ArrayList<Evento> eventos) {
		Palestra palestra = new Palestra();
		
		String cpfPalestrante = sc.next();
		
		for (Palestrante palestrante : palestrantes) {
			if(cpfPalestrante.equals(palestrante.getCpf())) {
				palestra.setPalestrante(palestrante);
			}
		}
		
		palestra.setNomeDaSala(sc.next());
		palestra.setHorario(sc.next());
		palestra.setTitulo(sc.next());
		palestra.setResumo(sc.next());
		
		String nomeEvento = sc.next();
		
		for (Evento evento : eventos) {
			if(nomeEvento.equals(evento.getNome())) {
				evento.getPalestras().add(palestra);
			}
		}
		
		
		return palestra;
	}
}
