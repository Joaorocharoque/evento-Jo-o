package br.com.senac.leitor;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

import br.com.senac.modelo.Palestrante;

public class PalestranteCSV {

	public ArrayList<Palestrante> lerArquivo() {
		ArrayList<Palestrante> palestrantes = new ArrayList<>();
		Scanner sc;
		
		try {
			sc = new Scanner(new File("palestrantes.csv"));
			sc.useDelimiter("[,\n]");

		} catch (FileNotFoundException e) {
			System.out.println("Arquivo não encontrado.");
			return palestrantes;
		}

		boolean ehPrimeiraLinha = true;

		while (sc.hasNext()) {
			if (ehPrimeiraLinha) {
				
				criaPalestrante(sc);
				
				ehPrimeiraLinha = false;
				
			} else {
				Palestrante p = criaPalestrante(sc);
				
				palestrantes.add(p);
			}
		}
		
		sc.close();
		
		return palestrantes;
	}

	private Palestrante criaPalestrante(Scanner sc) {
		Palestrante palestrante = new Palestrante();
		palestrante.setCpf(sc.next());
		palestrante.setNome(sc.next());
		palestrante.setEmail(sc.next());
		palestrante.setCurriculo(sc.next());
		palestrante.setTelefone(sc.next());
		
		return palestrante;
	}
}
